--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.4 (Debian 16.4-1.pgdg120+2)
-- Dumped by pg_dump version 16.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE autocad;
--
-- Name: autocad; Type: DATABASE; Schema: -; Owner: kid97yv
--

CREATE DATABASE autocad WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF8';


ALTER DATABASE autocad OWNER TO kid97yv;

\connect autocad

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: autocad; Type: DATABASE PROPERTIES; Schema: -; Owner: kid97yv
--

ALTER DATABASE autocad SET "TimeZone" TO 'utc';


\connect autocad

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: kid97yv
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO kid97yv;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Autosavelogs; Type: TABLE; Schema: public; Owner: kid97yv
--

CREATE TABLE public."Autosavelogs" (
    id integer NOT NULL,
    blueprint_id integer,
    saved_at timestamp without time zone,
    content text
);


ALTER TABLE public."Autosavelogs" OWNER TO kid97yv;

--
-- Name: Autosavelogs_id_seq; Type: SEQUENCE; Schema: public; Owner: kid97yv
--

ALTER TABLE public."Autosavelogs" ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Autosavelogs_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: Blueprint; Type: TABLE; Schema: public; Owner: kid97yv
--

CREATE TABLE public."Blueprint" (
    id integer NOT NULL,
    user_id integer,
    name character varying NOT NULL,
    content text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public."Blueprint" OWNER TO kid97yv;

--
-- Name: Files; Type: TABLE; Schema: public; Owner: kid97yv
--

CREATE TABLE public."Files" (
    id integer NOT NULL,
    user_id integer,
    file_name character varying NOT NULL,
    file_path text NOT NULL,
    uploaded_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public."Files" OWNER TO kid97yv;

--
-- Name: Files_id_seq; Type: SEQUENCE; Schema: public; Owner: kid97yv
--

ALTER TABLE public."Files" ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Files_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: Users; Type: TABLE; Schema: public; Owner: kid97yv
--

CREATE TABLE public."Users" (
    id integer NOT NULL,
    role character varying NOT NULL,
    email character varying NOT NULL,
    username character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone,
    password character varying NOT NULL
);


ALTER TABLE public."Users" OWNER TO kid97yv;

--
-- Name: Users_id_seq; Type: SEQUENCE; Schema: public; Owner: kid97yv
--

ALTER TABLE public."Users" ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Users_id_seq"
    START WITH 3
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: session; Type: TABLE; Schema: public; Owner: kid97yv
--

CREATE TABLE public.session (
    sid character varying NOT NULL,
    sess json,
    expire timestamp with time zone
);


ALTER TABLE public.session OWNER TO kid97yv;

--
-- Data for Name: Autosavelogs; Type: TABLE DATA; Schema: public; Owner: kid97yv
--

COPY public."Autosavelogs" (id, blueprint_id, saved_at, content) FROM stdin;
\.
COPY public."Autosavelogs" (id, blueprint_id, saved_at, content) FROM '$$PATH$$/3381.dat';

--
-- Data for Name: Blueprint; Type: TABLE DATA; Schema: public; Owner: kid97yv
--

COPY public."Blueprint" (id, user_id, name, content, created_at, updated_at) FROM stdin;
\.
COPY public."Blueprint" (id, user_id, name, content, created_at, updated_at) FROM '$$PATH$$/3383.dat';

--
-- Data for Name: Files; Type: TABLE DATA; Schema: public; Owner: kid97yv
--

COPY public."Files" (id, user_id, file_name, file_path, uploaded_at, updated_at) FROM stdin;
\.
COPY public."Files" (id, user_id, file_name, file_path, uploaded_at, updated_at) FROM '$$PATH$$/3384.dat';

--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: kid97yv
--

COPY public."Users" (id, role, email, username, created_at, updated_at, password) FROM stdin;
\.
COPY public."Users" (id, role, email, username, created_at, updated_at, password) FROM '$$PATH$$/3386.dat';

--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: kid97yv
--

COPY public.session (sid, sess, expire) FROM stdin;
\.
COPY public.session (sid, sess, expire) FROM '$$PATH$$/3388.dat';

--
-- Name: Autosavelogs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kid97yv
--

SELECT pg_catalog.setval('public."Autosavelogs_id_seq"', 2, true);


--
-- Name: Files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kid97yv
--

SELECT pg_catalog.setval('public."Files_id_seq"', 24855, true);


--
-- Name: Users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kid97yv
--

SELECT pg_catalog.setval('public."Users_id_seq"', 14, true);


--
-- Name: Autosavelogs autosavelogs_pk; Type: CONSTRAINT; Schema: public; Owner: kid97yv
--

ALTER TABLE ONLY public."Autosavelogs"
    ADD CONSTRAINT autosavelogs_pk PRIMARY KEY (id);


--
-- Name: Blueprint blueprint_pk; Type: CONSTRAINT; Schema: public; Owner: kid97yv
--

ALTER TABLE ONLY public."Blueprint"
    ADD CONSTRAINT blueprint_pk PRIMARY KEY (id);


--
-- Name: Files files_pk; Type: CONSTRAINT; Schema: public; Owner: kid97yv
--

ALTER TABLE ONLY public."Files"
    ADD CONSTRAINT files_pk PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: kid97yv
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: Users user_pk; Type: CONSTRAINT; Schema: public; Owner: kid97yv
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT user_pk PRIMARY KEY (id);


--
-- Name: Autosavelogs autosavelogs_blueprint_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kid97yv
--

ALTER TABLE ONLY public."Autosavelogs"
    ADD CONSTRAINT autosavelogs_blueprint_id_fk FOREIGN KEY (blueprint_id) REFERENCES public."Blueprint"(id);


--
-- Name: Blueprint blueprint_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kid97yv
--

ALTER TABLE ONLY public."Blueprint"
    ADD CONSTRAINT blueprint_user_id_fk FOREIGN KEY (user_id) REFERENCES public."Users"(id);


--
-- Name: Files files_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: kid97yv
--

ALTER TABLE ONLY public."Files"
    ADD CONSTRAINT files_user_id_fk FOREIGN KEY (user_id) REFERENCES public."Users"(id);


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON SEQUENCES TO kid97yv;


--
-- Name: DEFAULT PRIVILEGES FOR TYPES; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON TYPES TO kid97yv;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON FUNCTIONS TO kid97yv;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON TABLES TO kid97yv;


--
-- PostgreSQL database dump complete
--

